
package files;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class DynamicJson {
	
	@Test(dataProvider = "Books")
	public static void addBook(String isbn, String aisle)
	{
		RestAssured.baseURI="http://216.10.245.166";
		String response = given().log().all().header("Content-Type","application/json")
		.body(payload.Addbook(isbn,aisle))
		.when().post("/Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
		
		JsonPath js = ReUsableMethods.rawToJson(response);
		String id = js.get("ID");
		System.out.println(id);		
		
		String response1 = given().log().all().header("Content-Type","application/json")
				.body(payload.DeleteBook(id))
				.when().post("/Library/DeleteBook.php")
				.then().log().all().assertThat().statusCode(200)
				.extract().response().asString();
		JsonPath js1 = ReUsableMethods.rawToJson(response1);
		String Message = js1.get("msg");
		System.out.println(Message);
	}
	
	@DataProvider(name="Books")
	public Object[][] getData() {
		
	return new Object[][] {{"east","4444"},{"west","5555"},{"north","4565"}};	
	}

}

package excelIntegrationPackage;

import static io.restassured.RestAssured.given;

import java.util.HashMap;

import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class ExcelDrivenLibraryAPI2 {
	
	@Test
	public static void addBook()
	{
		
		HashMap<String, Object>  jsonAsMap = new HashMap<>();
		
		jsonAsMap.put("name", "ExcelIntegration");
		jsonAsMap.put("isbn", "112313");
		jsonAsMap.put("aisle", "12132343");
		jsonAsMap.put("author", "Dinesh");
		
		
		RestAssured.baseURI="http://216.10.245.166";
		String response = given().log().all().header("Content-Type","application/json")
		.body(jsonAsMap)
		.when().post("/Library/Addbook.php")
		.then().log().all().assertThat().statusCode(200)
		.extract().response().asString();
		
		JsonPath js = ReUsableMethods.rawToJson(response);
		String id = js.get("ID");
		System.out.println(id);		
	}
	

}
